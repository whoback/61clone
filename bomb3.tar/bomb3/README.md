CS 61 Problem Set 2
===================

This is bomb #3.

It belongs to whoback (will.hoback@gmail.com).
